const palavras = ["banana", "laranja", "manga", "uva", "abacaxi","morango","amoras","abacate"];
let palavraSecreta = palavras[Math.floor(Math.random() * palavras.length)];
let letrasCorretas = Array(palavraSecreta.length).fill("_");
let letrasErradas = [];
let tentativas = 6; // Número de tentativas permitidas
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

function desenharBoneco(tentativas) {
    ctx.clearRect(0, 0, canvas.width, canvas.height); // Limpa o canvas
    ctx.beginPath();
    
    if (tentativas < 6) { // Cabeça
        ctx.arc(100, 30, 20, 0, Math.PI * 2);
    }
    if (tentativas < 5) { // Corpo
        ctx.moveTo(100, 50);
        ctx.lineTo(100, 150);
    }
    if (tentativas < 4) { // Braço esquerdo
        ctx.moveTo(100, 70);
        ctx.lineTo(60, 100);
    }
    if (tentativas < 3) { // Braço direito
        ctx.moveTo(100, 70);
        ctx.lineTo(140, 100);
    }
    if (tentativas < 2) { // Perna esquerda
        ctx.moveTo(100, 150);
        ctx.lineTo(60, 180);
    }
    if (tentativas < 1) { // Perna direita
        ctx.moveTo(100, 150);
        ctx.lineTo(140, 180);
    }

    ctx.stroke();
}

document.getElementById("adivinhar").addEventListener("click", function() {
    const letra = document.getElementById("letra").value.toLowerCase();
    document.getElementById("letra").value = ""; // Limpa o campo de entrada

    if (letra.length !== 1 || !/^[a-z]$/.test(letra)) {
        alert("Por favor, digite apenas uma letra.");
        return;
    }

    if (palavraSecreta.includes(letra)) {
        for (let i = 0; i < palavraSecreta.length; i++) {
            if (palavraSecreta[i] === letra) {
                letrasCorretas[i] = letra;
            }
        }
        document.getElementById("resultado").textContent = `Letras corretas: ${letrasCorretas.join(" ")}`;
        
        if (!letrasCorretas.includes("_")) {
            document.getElementById("resultado").textContent = `Parabéns! Você adivinhou a palavra: ${palavraSecreta}`;
            document.getElementById("reiniciar").style.display = "block";
            document.getElementById("adivinhar").disabled = true; // Desabilita o botão
        }
    } else {
        if (!letrasErradas.includes(letra)) {
            letrasErradas.push(letra);
            tentativas--;
            desenharBoneco(tentativas);
            document.getElementById("resultado").textContent = `Letras erradas: ${letrasErradas.join(", ")}`;
            
            if (tentativas === 0) {
                document.getElementById("resultado").textContent = `Você perdeu! A palavra era: ${palavraSecreta}`;
                document.getElementById("reiniciar").style.display = "block";
                document.getElementById("adivinhar").disabled = true; // Desabilita o botão
            }
        }
    }

    document.getElementById("palavraSecreta").textContent = letrasCorretas.join(" ");
});

document.getElementById("reiniciar").addEventListener("click", function() {
    palavraSecreta = palavras[Math.floor(Math.random() * palavras.length)];
    letrasCorretas = Array(palavraSecreta.length).fill("_");
    letrasErradas = [];
    tentativas = 6; // Reinicia as tentativas
    ctx.clearRect(0, 0, canvas.width, canvas.height); // Limpa o canvas
    document.getElementById("resultado").textContent = "";
    document.getElementById("palavraSecreta").textContent = "";
    document.getElementById("letra").value = "";
    document.getElementById("reiniciar").style.display = "none";
    document.getElementById("adivinhar").disabled = false; // Habilita o botão novamente
});